# GOT-Inspired-Map
A GOT-inspired map style and files

Winter is here! We’re pretty amped for the final season of Game of Thrones. Since we love GOT and love making maps, we thought we'd combine the two with this Game of thrones-inspired map style. 

Bring this style directly into you Mapbox Studio account here: []
https://www.mapbox.com/studio/styles/add-style/mapbox/cjuah12up9qs41fo96ruvf7x8/?utm_medium=community&utm_source=github&utm_campaign=community|github|mobile|GOT-Inspired-map-19-05&utm_term=mobile&utm_content=GOT-Inspired-map		

Publish your finished map and share it with us on twitter #builtwithmapbox. 

#### Attribution 

This repo contains the raw map data file compiled by cadaei, theMountainGoat and Tear based on original books by George RR Martin. See license [here](GoTRelease/LICENSE.md). For the map, we added region boundaries, region labels, and bathmetry.